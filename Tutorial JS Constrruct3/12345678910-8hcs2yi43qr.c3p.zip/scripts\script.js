// Learn JavaScript in Construct, part 1: getting started

console.log("Hello world!");

console.log("My super cool message!");


// Learn JavaScript in Construct, part 2: language basics


console.log("First message!");
console.log("Second message!");

// First line of comment
// Second line of comment
// Third line of comment


/* First line of comment
Second line of comment
Third line of comment */


/* comment before code */ console.log("Hello world!");
console.log(/* comment inside code */ "Hello world!");

let message;
message = "Hello world!";

//let message;
message = "Hello world!";
console.log(message);

//let message = "Hello world!";

/*let firstName, lastName, food = "pizza", drink = "cola";*/

let firstName;
let lastName;
//let food = "pizza";
let drink = "cola";

//let message;
message = "First message!";
message = "Second message!";
console.log(message);

//let message;
console.log(message);

// ReferenceError: Cannot access 'message' before initialization
console.log(message);
//let message = "Hello world!";

//let message = "First message!";
// SyntaxError: Identifier 'message' has already been declared
//let message = "Second message!";

// Valid variable names:
let userName;
let user_name;
let testing123;

// Invalid variable names:
//let user-name;	// dash '-' not allowed
//let 9slice;	// starting with digit not allowed
//let let;	// keyword not allowed


// Declare a constant
const PI = 3.141592653589793;

// TypeError: Assignment to constant variable.
PI = 4;

//var message = "Hello world!";

let score = 100;
console.log(score);

// Try entering in to the console:
10 + 5    // 15
7 - 4     // 3
6 * 3     // 18
20 / 4    // 5

let value = 10 + 5;
value = 6 * 3;          // replaces value
console.log(value + 1); // 19

let a = 2 + 1.5;
let b = a * 2;
console.log(b);  // 7

// Try entering in to the console:
0.1 + 0.2   // 0.30000000000000004

// Try entering in to the console:
1 / 0          // Infinity
-1 / 0         // -Infinity
Infinity + 1   // Infinity

// Try entering in to the console:
0 / 0          // NaN

"Hello world!"
'Hello world!'
`Hello world!`

// Try entering in to the console:
"Hello \"world\"!"  // Hello "world"!

let b = true;
console.log(b);

let foo = "string";
foo = 10;     // changing to number
foo = false;  // changing to boolean

// Try entering in to the console:
typeof 100       // number
typeof "Hello"   // string
typeof true      // boolean

let myVar = "Hello";  // start off with string
myVar = 100;          // change to number

// ... lots more code ...

// What type is myVar?
console.log(typeof myVar); // number

// Try entering in to the console:
typeof undefined	// "undefined"

let unassignedVariable;
console.log(typeof unnasignedVariable);	// undefined



//Learn JavaScript in Construct, part 3: operators

// Try entering in to the console:
13 % 5		// 3
5 % 2		// 1
27 % 10		// 7

// Try entering in to the console:
5.5 % 2		// 1.5
9 % 3.5		// 2
3.25 % 1.25	// 0.75

// Try entering in to the console:
6 ** 2			// 36
2 ** 3			// 8
100 ** (1/2)	// 10
1.5 ** 2		// 2.25
6.25 ** 0.5		// 2.5

let number = 7;
number = number * 2;
console.log(number);	// 14

//let number = 7;
number *= 2;
console.log(number);	// 14


let a = 2;
console.log(a += 2);	// logs 4

// These lines all do the same thing:
a = a + 1;
a += 1;
a++;

let a = 1;
console.log(a++);
console.log(a);

//let a = 1;
console.log(++a);
console.log(a);


// Try entering in to the console:
"Hello " + "world!"  // Hello world!

//let score = 100;
console.log("Your score is " + score + "!");
// Your score is 100!

//let score = 100;
console.log(`Your score is ${score}!`);
// Your score is 100!

// Try entering in to the console:
"5" + "5"	// "55" (string)
"5" + 5		// "55" (string)
5 + "5"		// "55" (string)
5 + 5		// 10 (number)

// Try entering in to the console:
Number("5")		// 5 (number)
Number("-6.5")	// -6.5 (number)
Number(5)		// 5 (still a number)
Number("Hello")	// NaN

String(5)		// "5" (string)
String(-6.5)	// "-6.5" (string)
String("Hello")	// "Hello" (still a string)
String(NaN)		// "NaN" (string)

// Try entering in to the console:
5 == 5		// true
5 == "5"	// true (converts types)
5 === 5		// true
5 === "5"	// false (types are different)

// Try entering in to the console:
5 != "5"	// false (converts types)
5 !== "5"	// true (types are different)

// Try entering in to the console:
Boolean(0)			// false (is zero)
Boolean(NaN)		// false (is NaN)
Boolean(1)			// true (is not zero or NaN)
Boolean(42)			// true (is not zero or NaN)
Boolean(Infinity)	// true (is not zero or NaN)

Boolean("")			// false (is empty string)
Boolean("Hello")	// true (is not empty string)
Boolean("0")		// true (is not empty string)

Boolean(undefined)	// false

Boolean(true)		// true (no change)
Boolean(false)		// false (no change)

let b = true;
console.log(!b);  // false

// Try entering in to the console:
false || false		// false
false || true		// true
true || false		// true
true || true		// true

false && false		// false
false && true		// false
true && false		// false
true && true		// true

//let score = 120;
console.log(score >= 100 ? "Nice score!" : "Try again!");

// Try entering in to the console:
0 ? "truthy" : "falsy"			// "falsy"
1 ? "truthy" : "falsy"			// "truthy"
"" ? "truthy" : "falsy"			// "falsy"
"Hello!" ? "truthy" : "falsy"	// "truthy"


//Learn JavaScript in Construct, part 4: control flow

if (condition)
{
	// Statements to run if condition is true
}

// The following statements always run


//let number = 5;
if (number < 10)
{
	console.log("Number is less than 10!");
}

console.log("Logged after if statement");


//let number = 15;
if (number < 10)
{
	console.log("Number is less than 10!");
}
else
{
	console.log("Number is greater or equal to 10!");
}

//let number = 15;
if (number < 10)
{
	console.log("Number is less than 10!");
}
else if (number < 20)
{
	console.log("Number is between 10 and 20!");
}
else
{
	console.log("Number is greater or equal to 20!");
}


if (number < 10)
{
	console.log("Number is less than 10!");
}

if (number < 10)
	console.log("Number is less than 10!");

  //  let number = 15;
if (number < 10)
{
	console.log("Number is less than 10!");
}
else if (number < 20)
{
	console.log("Number is between 10 and 20!");
}
else
{
	console.log("Number is greater or equal to 20!");
}

//let number = 15;
if (number < 10)
	console.log("Number is less than 10!");
else if (number < 20)
	console.log("Number is between 10 and 20!");
else
	console.log("Number is greater or equal to 20!");

if (number < 10)
{
	console.log("Number is less than 10!");
}

if (number < 10) {
	console.log("Number is less than 10!");
}

if (number < 10)
	console.log("Number is less than 10!");

if(number<10)console.log("Number is less than 10!");

if (number < 10) { console.log("Number is less than 10!"); }

if    (number    <    10)
{
console.log("Number is less than 10!"); 

}

if (number < 10)
	console.log("First message!");
	console.log("Second message!");

    if (number < 10)
{
	console.log("First message!");
}

console.log("Second message!");

//let number = 5;
let message;
if (number < 5)
{
	message = "Number is less than 5!";
}
else
{
	message = "Number is greater or equal to 5!";
}
console.log(message);

//let number = 5;
let message = number < 5 ? "Number is less than 5!" : "Number is greater or equal to 5!";
console.log(message);


// This is the number the player must guess.
let theNumber = getTheNumber();

// This is the number the player just guessed.
let guessedNumber = getEnteredNumber();
let message;

// Set the message to display.
if (guessedNumber < theNumber)
{
	message = "Higher!";
}
else if (guessedNumber > theNumber)
{
	message = "Lower!";
}
else
{
	message = "That's it!";
}

// Show the message.
showResultMessage(message);

while (condition)
{
	// statements to repeat
}

let i = 0;
while (i < 3)
{
	console.log(`Variable 'i' is ${i}`);
	i++;
}

begin
while (condition)
{
	// loop body

	step
}

for (begin; condition; step)
{
	// loop body
}

for (let i = 0; i < 3; i++)
{
	console.log(`Variable 'i' is ${i}`);
}

let i = 0;
for ( ; i < 3; i++)	// note first part left empty
{
	console.log(`Variable 'i' is ${i}`);
}

for (let i = 0; i < 10; i++)
{
	console.log(`Variable 'i' is ${i}`);

	if (i === 5)
		break;	// end loop early
}

//let i = 0;
while (true)
{
	console.log(`Variable 'i' is ${i}`);
	i++;

	if (i === 5)
		break;	// end infinite loop
}

for (let i = 0; i < 10; i++)
{
	if (i === 5)
		continue;	// skip logging message

	console.log(`Variable 'i' is ${i}`);
}

//let number = 5;
switch (number) {
case 0:
	console.log("Number is 0!");
	break;
case 5:
	console.log("Number is 5!");
	break;
case 10:
	console.log("Number is 10!");
	break;
default:
	console.log("Number is something else!");
	break;
}

//let number = 5;
if (number === 0)
{
	console.log("Number is 0!");
}
else if (number === 5)
{
	console.log("Number is 5!");
}
else if (number === 10)
{
	console.log("Number is 10!");
}
else
{
	console.log("Number is something else!");
}

//let number = 5;
switch (number) {
case 0:
	console.log("Number is 0!");
case 5:
	console.log("Number is 5!");
case 10:
	console.log("Number is 10!");
default:
	console.log("Number is something else!");
}

//let number = 5;
switch (number) {
case 0:
	console.log("Number is 0!");
	break;
case 5:
case 10:
	console.log("Number is 5 or 10!");
	break;
default:
	console.log("Number is something else!");
	break;
}

// Learn JavaScript in Construct, part 5: Functions

console.log("Hello world!");

function logMessage()
{
	console.log("Hello world!");
}

// Declare function
function logMessage()
{
	console.log("Hello world!");
}

// Call the function
logMessage();



// Learn JavaScript in Construct, part 7: Objects


let myObject = {
    firstProp: "Hello world", secondProp: 123
};
console.log(typeof myObject); //object

// tambien puede ser asi 

console.log(myObject.firstProp);

console.log(myObject.thirdProp);

myObject.thirdProp = 456;

//create an empty object
let myObject = {};

//add a property to it (which could be done conditionally)
myObject.firstProp = "Hello World";

console.log(myObject);

let myObject = {
    firstProp: "HelloWorld",
    secondProp:123
};

//delete secondProp from the object
delete myObject.secondProp;

//log entire object to console
console.log(myObject);

let myObject = {
    //use a string for a property name 
    "myProperty": 5
};

//this is equivalent to:
let myObject = {
    myProperty:5
};

let myObject ={
    "my property!":5
};

//Assign to a string property
myObject["My property!"]=7;

//read a string porperty
console.log (myObject["my property!"]); // 7

let myObject = {
myProperty:5
};

//read with dot property
console.log(myObject.myProperty); // 5 

//read with string porperty
console.log (myObject["myPrperty"]); // 5

let myObject = {
myProperty:5
};

//acces a porperty via a string variable
let propName = "myProperty";
console.log(myObject[propName]);// 5

let myObject = {
    myProperty: 5
};

//access a property via a string variable
//let propName = "myProperty";

console.log(myObject[propName]); // 5

let myObject = {
    myProperty: undefined
};

//reading a missing property returns undefined
console.log (myObject.otherProperty); // undefined

console.log(myObject.myProperty); // undefined

let myObject={
    myProperty: undefined
};

console.log("otherProperty" in myObject);
console.log("myProperty" in myObject);

let person = {
    // the "name" property is another object
    name:{
        first:"Joe",
        last: "Bloggs"
    },
    age:30
};

//Access the first name with dots
console.log(person.name.first);
//access the first name with strings 
console.log(person["name"]["first"]); //

let myObject = {
    //prefer to use null for empty properties
    myProperty:null
};

let obj = null;
//typeError:cannot read properties of null (reading "name")
console.log(obj.name);

let myObject ={
    myProperty: null
};

//typeError: cannot read properties of null (reading "anotherProperty")
console.log(myObject.myProperty.anotherProperty);

let myObject={
    myProperty: null
};

console.log(myObject?.myProperty?.anotherProperty); // undefined

let obj = null;
console.log(log?.firstProperty?.secondProperty?.thirdProperty);

let result;

let obj = null;
//Check the object and every single expected property exist

if(obj &&
    obj.firstProperty &&
    obj.firstProperty.secondProperty &&
    obj.firstProperty.secondProperty.thirdProperty){
    // all properties exist:read the result
    result = obj.firstProperty.secondProperty.thirdProperty;
    }
    console.log(result);

    let myObject={
        myProperty:null
    };

    console.log(myObject?.["myProperty"]?.["anotherProperty"]);

    let someFunction = null;

    //not an error even though someFunction is null,
    //because optional ?. () syntax used

    console.log(someFunction?.());

    function logFood(obj)
{
	// Log the "food" property of the object
	console.log(obj.food);
}

// An object can be passed via a variable storing an object.
let myObject = {
	food: "banana"
};

logFood(myObject);	// logs "banana"

// An object can also be passed directly. This logs "pizza".
logFood({
	food: "pizza"
});


// Create a variable with a string.
let food1 = "pizza";

// Create another variable and assign it the same string.
// This creates a second copy of the string for this variable.
let food2 = food1;

// Change the food2 variable.
food2 = "noodles";

// Log both variables. They are different.
console.log(`food1 is: ${food1}`);
console.log(`food2 is: ${food2}`);


// Create a variable with an object.
let ref1 = {
	food: "pizza"
};

// Create a variable also assigned to the same object.
let ref2 = ref1;

// Change the 'food' property through the second variable.
ref2.food = "noodles";

// Log the 'food' property of both variables. They are the same,
// as they both reference the same object.
console.log(`ref1.food is: ${ref1.food}`);
console.log(`ref2.food is: ${ref2.food}`);


function changeFood(food)
{
	// Change the parameter. This does not affect
	// the originally passed variable.
	food = "noodles";
}

// The variable starts off with the string "pizza"
let food = "pizza";

console.log(`First, the food is: ${food}`);

// Calling the function does not change the variable
changeFood(food);

// Log the variable again. It's still "pizza".
console.log(`Second, the food is: ${food}`);


function changeFoodProperty(obj)
{
	// Change the property. This affects
	// the originally passed object.
	obj.food = "noodles";
}

// The 'food' property starts off as "pizza"
let myObject = {
	food: "pizza"
};

console.log(`First, the food is: ${myObject.food}`);

// Calling the function changes the 'food' property
changeFoodProperty(myObject);

// Log the 'food' property again - it's now "noodles"
console.log(`Second, the food is: ${myObject.food}`);


// Create an object
let objA = {
	food: "pizza"
};

// objB refers to the same object as objA
let objB = objA;

// objC refers to a different object, even though
// it has the same property and value
let objC = {
	food: "pizza"
};

// Display equality
console.log("objA === objB: ", objA === objB);	// true
console.log("objA === objC: ", objA === objC);	// false


// Add a property on the global object.
globalThis.myGlobal = "Hello world!";

// Logs "Hello world!".
// This will also work in other script files,
// as the global object is available everywhere.
console.log(globalThis.myGlobal);


// Add a global property named myGlobal
globalThis.myGlobal = "Initial string";

// Assign myGlobal as if it's a variable
myGlobal = "Hello world!";

// Log myGlobal as if it's a variable
console.log(myGlobal);	// Hello world!


// ReferenceError: doesNotExist is not defined
console.log(doesNotExist);


// ReferenceError: myGlobal is not defined
myGlobal = "Hello world!";


globalThis.console.log("Hello world!");


